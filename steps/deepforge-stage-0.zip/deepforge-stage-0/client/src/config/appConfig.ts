export const APP_CONFIG = {
  gameName: 'DEEPFORGE: Idle Empire',
  saveSchemaVersion: 1,
  apiBaseUrl: import.meta.env.VITE_API_URL ?? 'http://localhost:3001',
  mobileMinWidth: 360,
  targetFpsHigh: 60,
  targetFpsLow: 30,
} as const;
