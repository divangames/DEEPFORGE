import { create } from 'zustand';
import type { QualityTier } from '../core/device';
import { detectQualityTier } from '../core/device';

interface GameState {
  cash: number;
  quality: QualityTier;
  apiOnline: boolean | null;
  setApiOnline: (online: boolean) => void;
  setQuality: (quality: QualityTier) => void;
  addCash: (amount: number) => void;
}

export const useGameStore = create<GameState>((set) => ({
  cash: 0,
  quality: detectQualityTier(),
  apiOnline: null,
  setApiOnline: (apiOnline) => set({ apiOnline }),
  setQuality: (quality) => set({ quality }),
  addCash: (amount) => set((state) => ({ cash: state.cash + amount })),
}));
