import Phaser from 'phaser';

export class FoundationScene extends Phaser.Scene {
  private title?: Phaser.GameObjects.Text;
  private hint?: Phaser.GameObjects.Text;
  private surface?: Phaser.GameObjects.Rectangle;
  private mine?: Phaser.GameObjects.Rectangle;
  private lift?: Phaser.GameObjects.Rectangle;

  constructor() {
    super('FoundationScene');
  }

  create() {
    this.cameras.main.setBackgroundColor('#15181d');

    this.surface = this.add.rectangle(0, 0, 100, 100, 0x252b32).setOrigin(0.5);
    this.mine = this.add.rectangle(0, 0, 100, 100, 0x1d2228).setOrigin(0.5);
    this.lift = this.add.rectangle(0, 0, 18, 100, 0xf0b429).setOrigin(0.5);

    this.title = this.add.text(0, 0, 'DEEPFORGE', {
      fontFamily: 'Arial, sans-serif',
      fontSize: '28px',
      color: '#f5f7fa',
      fontStyle: 'bold',
    }).setOrigin(0.5);

    this.hint = this.add.text(0, 0, 'FOUNDATION READY\nСледующий этап: рабочая производственная цепочка', {
      fontFamily: 'Arial, sans-serif',
      fontSize: '13px',
      color: '#aab4bf',
      align: 'center',
      lineSpacing: 5,
    }).setOrigin(0.5);

    this.scale.on('resize', this.layout, this);
    this.layout({ width: this.scale.width, height: this.scale.height } as Phaser.Structs.Size);
  }

  private layout(gameSize: Phaser.Structs.Size) {
    const width = gameSize.width;
    const height = gameSize.height;
    const surfaceHeight = Math.max(86, height * 0.22);
    const mineTop = surfaceHeight;
    const mineHeight = Math.max(180, height - surfaceHeight);

    this.surface?.setPosition(width / 2, surfaceHeight / 2).setSize(width, surfaceHeight);
    this.mine?.setPosition(width / 2, mineTop + mineHeight / 2).setSize(width, mineHeight);
    this.lift?.setPosition(width / 2, mineTop + mineHeight / 2).setSize(Math.max(14, width * 0.045), mineHeight * 0.82);
    this.title?.setPosition(width / 2, Math.max(32, surfaceHeight * 0.35));
    this.hint?.setPosition(width / 2, mineTop + mineHeight * 0.48);
  }
}
