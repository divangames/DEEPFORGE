import { APP_CONFIG } from '../config/appConfig';
import { gameDb } from './gameDb';

export interface FoundationSave {
  createdAt: number;
  lastSeenAt: number;
  settings: {
    quality: 'LOW' | 'MEDIUM' | 'HIGH';
  };
}

export async function saveFoundationState(payload: FoundationSave) {
  await gameDb.saves.put({
    id: 'primary',
    schemaVersion: APP_CONFIG.saveSchemaVersion,
    updatedAt: Date.now(),
    payload,
  });
}

export async function loadFoundationState() {
  return gameDb.saves.get('primary');
}
