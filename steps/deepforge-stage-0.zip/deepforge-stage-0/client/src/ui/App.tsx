import { useEffect } from 'react';
import { getApiHealth } from '../services/api';
import { useGameStore } from '../state/gameStore';
import { GameCanvas } from './GameCanvas';

export function App() {
  const quality = useGameStore((state) => state.quality);
  const apiOnline = useGameStore((state) => state.apiOnline);
  const setApiOnline = useGameStore((state) => state.setApiOnline);

  useEffect(() => {
    const controller = new AbortController();
    const timer = window.setTimeout(() => controller.abort(), 2500);

    getApiHealth(controller.signal)
      .then(() => setApiOnline(true))
      .catch(() => setApiOnline(false))
      .finally(() => window.clearTimeout(timer));

    return () => {
      window.clearTimeout(timer);
      controller.abort();
    };
  }, [setApiOnline]);

  return (
    <main className="app-shell">
      <header className="topbar">
        <div className="brand">
          <span className="brand-mark">DF</span>
          <span>DEEPFORGE</span>
        </div>
        <div className="resource-pill" title="Основная валюта появится в Этапе 1">$ 0</div>
      </header>

      <section className="game-stage">
        <GameCanvas />
        <div className="foundation-badge">
          <strong>STAGE 0</strong>
          <span>Quality: {quality}</span>
          <span className={apiOnline ? 'ok' : 'warn'}>
            API: {apiOnline === null ? 'CHECK…' : apiOnline ? 'ONLINE' : 'OFFLINE'}
          </span>
        </div>
      </section>

      <nav className="bottom-nav" aria-label="Главная навигация">
        <button type="button" className="active">Объект</button>
        <button type="button" disabled>Карта</button>
        <button type="button" disabled>Команда</button>
        <button type="button" disabled>Ещё</button>
      </nav>
    </main>
  );
}
