# CHANGELOG

## 0.0.1 — Stage 0 Foundation

- Создан monorepo client/server.
- Добавлен React + TypeScript UI.
- Добавлен Phaser Canvas и адаптивная foundation-сцена.
- Добавлена mobile-first навигация и safe-area поддержка.
- Добавлен IndexedDB слой через Dexie.
- Добавлен Zustand store.
- Добавлен PWA manifest/service worker.
- Добавлен Fastify API и `/api/health`.
- Подготовлена PostgreSQL схема сохранений.
- Добавлен Docker Compose для локального PostgreSQL.
- Добавлены `dev.bat`, `build.bat`, `deploy.bat`.
- Добавлены базовые тесты viewport breakpoints.
- Добавлена типизация virtual PWA module.
- Добавлен server health unit-test.
