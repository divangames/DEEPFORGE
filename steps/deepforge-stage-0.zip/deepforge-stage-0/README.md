# DEEPFORGE: Idle Empire — Stage 0

Фундамент браузерной mobile-first idle/tycoon игры.

## Что уже есть

- React + TypeScript UI.
- Phaser Canvas для игровой сцены.
- Адаптация телефон / планшет / ПК.
- PWA manifest + service worker.
- IndexedDB через Dexie для локальных сохранений.
- Zustand для UI/game state.
- Fastify API.
- PostgreSQL-заготовка и SQL-схема.
- API health check.
- Windows `.bat` для запуска, сборки и подготовки деплоя.
- Минимальные unit-тесты.

## Требования

- Node.js 22.12+
- npm
- Docker Desktop — только если нужен локальный PostgreSQL

## Быстрый запуск Windows

Запустить:

`dev.bat`

Первый запуск сам установит зависимости.

Клиент:

`http://localhost:5173`

API:

`http://localhost:3001/api/health`

## PostgreSQL локально

Не обязателен для проверки Stage 0.

Если Docker установлен:

`docker compose up -d postgres`

После этого перезапустить `dev.bat`.

## Проверка проекта

`build.bat`

Он выполняет:

1. typecheck;
2. tests;
3. production build.

## Следующий этап

Stage 1 — Core Vertical Slice:

добыча → буфер этажа → Lift → Surface Buffer → Logistics → деньги → Upgrade.

В Stage 1 визуальные прямоугольники заменяются рабочими игровыми сущностями, но финальные Adobe-ассеты пока не нужны.
